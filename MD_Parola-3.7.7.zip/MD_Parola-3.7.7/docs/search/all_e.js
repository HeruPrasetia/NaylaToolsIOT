var searchData=
[
  ['texteffect_5ft_0',['textEffect_t',['../_m_d___parola_8h.html#acf3b849a996dbbe48ca173d2b0b82eda',1,'MD_Parola.h']]],
  ['textposition_5ft_1',['textPosition_t',['../_m_d___parola_8h.html#abab52de9e46b83d0aa94f0e3439e224d',1,'MD_Parola.h']]],
  ['the_20library_2',['Support the Library',['../page_donation.html',1,'index']]],
  ['time_5fprofiling_3',['TIME_PROFILING',['../_m_d___parola__lib_8h.html#ad5074ed4add7f6c0b8052896efd82cd3',1,'MD_Parola_lib.h']]]
];
